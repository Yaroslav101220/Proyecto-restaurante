document.addEventListener('DOMContentLoaded', () => {
    const listaPedido = document.getElementById('lista-pedido');
    const totalCopElement = document.getElementById('total-cop');
    const totalUsdElement = document.getElementById('total-usd');
    const confirmarPedidoBtn = document.getElementById('confirmar-pedido');
    const mensajeConfirmacion = document.getElementById('mensaje-confirmacion');
    const nuevoPedidoBtn = document.getElementById('nuevo-pedido');
    const notas = document.getElementById('notas');
    
    let pedido = [];
    let totalCop = 0;
    let totalUsd = 0;

    // Función para actualizar el total
    const actualizarTotal = () => {
        totalCop = pedido.reduce((sum, item) => sum + (item.precioCop * item.cantidad), 0);
        totalUsd = pedido.reduce((sum, item) => sum + (item.precioUsd * item.cantidad), 0);
        totalCopElement.textContent = `$${totalCop.toLocaleString('es-CO')} COP`;
        totalUsdElement.textContent = `$${totalUsd.toFixed(2)} USD`;
    };

    // Función para renderizar el pedido
    const renderizarPedido = () => {
        listaPedido.innerHTML = '';
        pedido.forEach((item, index) => {
            const li = document.createElement('li');
            li.innerHTML = `
                ${item.nombre}${item.sabor ? ` (${item.sabor})` : ''} 
                <div class="cantidad">
                    <button class="btn-cantidad" onclick="modificarCantidad(${index}, -1)">-</button>
                    <span>x${item.cantidad}</span>
                    <button class="btn-cantidad" onclick="modificarCantidad(${index}, 1)">+</button>
                </div>
                <button onclick="eliminarPlato(${index})"><i class="fas fa-trash"></i></button>
            `;
            listaPedido.appendChild(li);
        });
        actualizarTotal();
    };

    // Función para modificar cantidad
    window.modificarCantidad = (index, cambio) => {
        pedido[index].cantidad += cambio;
        if (pedido[index].cantidad < 1) pedido.splice(index, 1);
        renderizarPedido();
    };

    // Función para eliminar plato
    window.eliminarPlato = (index) => {
        pedido.splice(index, 1);
        renderizarPedido();
    };

    // Agregar platos al pedido
    document.querySelectorAll('.agregar').forEach(button => {
        button.addEventListener('click', () => {
            const platoPadre = button.closest('.plato');
            const nombre = button.getAttribute('data-nombre');
            const sabor = platoPadre.querySelector('.sabor-jugo')?.value;
            const precioCop = parseFloat(button.getAttribute('data-precio-cop'));
            const precioUsd = parseFloat(button.getAttribute('data-precio-usd'));

            // Buscar si ya existe el mismo ítem
            const itemExistente = pedido.find(item => 
                item.nombre === nombre && 
                (!item.sabor || item.sabor === sabor)
            );

            if (itemExistente) {
                itemExistente.cantidad++;
            } else {
                pedido.push({ 
                    nombre, 
                    sabor,
                    precioCop, 
                    precioUsd, 
                    cantidad: 1 
                });
            }

            renderizarPedido();

            // Notificación mejorada para todos los dispositivos
            Swal.fire({
                icon: 'success',
                title: '¡Añadido!',
                text: `${nombre}${sabor ? ` (${sabor})` : ''} se ha añadido al pedido.`,
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true,
                background: '#28a745',
                color: '#fff',
                iconColor: '#fff'
            });
        });
    });

    // Confirmar pedido (versión mejorada)
    confirmarPedidoBtn.addEventListener('click', () => {
        if (pedido.length === 0) {
            Swal.fire({
                icon: 'warning',
                title: 'Pedido vacío',
                text: 'Agrega al menos un plato al pedido.',
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 2000
            });
            return;
        }

        Swal.fire({
            title: '¿Confirmar pedido?',
            html: `Total: <b>$${totalCop.toLocaleString('es-CO')} COP</b><br>($${totalUsd.toFixed(2)} USD)`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#28a745',
            cancelButtonColor: '#dc3545',
            confirmButtonText: '¡Sí, enviar!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                const nota = notas.value;
                fetch('http://192.168.100.168:3000/orden', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ pedido, totalCop, totalUsd, nota })
                })
                .then(response => {
                    if (response.ok) {
                        // Notificación mejorada para todos los dispositivos
                        Swal.fire({
                            title: '¡Enviado!',
                            text: 'Pedido enviado a cocina',
                            icon: 'success',
                            toast: true,
                            position: 'top-end',
                            timer: 3000
                        });

                        // Sonido opcional (con manejo de errores)
                        new Audio('/notification.mp3').play().catch(() => {});

                        // Reiniciar interfaz
                        mensajeConfirmacion.classList.remove('mensaje-oculto');
                        pedido = [];
                        listaPedido.innerHTML = '';
                        totalCopElement.textContent = '$0 COP';
                        totalUsdElement.textContent = '$0.00 USD';
                        notas.value = '';
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'No se pudo enviar el pedido',
                            toast: true,
                            position: 'top-end',
                            timer: 3000
                        });
                    }
                })
                .catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error de conexión',
                        text: error.message,
                        toast: true,
                        position: 'top-end',
                        timer: 3000
                    });
                });
            }
        });
    });

    // Botón para nuevo pedido
    nuevoPedidoBtn.addEventListener('click', () => {
        mensajeConfirmacion.classList.add('mensaje-oculto');
    });
});