const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const cors = require('cors'); // Para evitar problemas de CORS

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*", // Permite conexiones desde cualquier origen
        methods: ["GET", "POST"]
    }
});

// Almacén de órdenes en memoria
let ordenes = [];

app.use(cors()); // Habilita CORS
app.use(express.static(path.join(__dirname, '../frontend/menu')));
app.use(express.json());

const validarPedido = (pedido) => {
    return Array.isArray(pedido) && pedido.every(item => 
        item.nombre && item.precioCop && item.precioUsd && item.cantidad
    );
};

// Endpoints
app.get('/ordenes', (req, res) => {
    res.json(ordenes);
});

app.post('/orden', (req, res) => {
    if (!validarPedido(req.body.pedido)) {
        return res.status(400).send('Formato de pedido inválido');
    }

    const newOrder = {
        ...req.body,
        id: Date.now(),
        status: 'preparando',
        prioridad: req.body.pedido.some(item => item.nombre.toLowerCase().includes('bebida')) ? 'baja' : 'alta',
        timestamp: new Date().toLocaleTimeString()
    };

    ordenes.unshift(newOrder); // Nuevos pedidos al inicio
    io.emit('nueva-orden', newOrder);
    res.sendStatus(200);
});

app.put('/orden/:id', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    
    const orderIndex = ordenes.findIndex(o => o.id == id);
    if (orderIndex !== -1) {
        ordenes[orderIndex].status = status;
        io.emit('actualizar-estado', { id: Number(id), status });
        res.sendStatus(200);
    } else {
        res.sendStatus(404);
    }
});

// Rutas
app.get('/cocina', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/menu/cocina.html'));
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/menu/index.html'));
});

const PORT = process.env.PORT || 3000;
const IP = '192.168.100.168'; // Tu IP local
server.listen(PORT, IP, () => {
    console.log(`✅ Servidor en http://${IP}:${PORT}`);
    console.log(`🔴 Cocina: http://${IP}:${PORT}/cocina`);
});